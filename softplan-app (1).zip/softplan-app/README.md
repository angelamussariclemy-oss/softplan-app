# Soft Plan — planner di Angela

App installabile (PWA) con planner settimanale universitario, orari 8–23, dal 1° settembre 2026 al 30 settembre 2027, e sincronizzazione con Google Calendar.

## Contenuto della cartella
- `index.html` — l'app
- `manifest.json` — descrive l'app per renderla installabile
- `service-worker.js` — permette il funzionamento offline
- `icons/` — icone dell'app

## Come installarla come app vera

Una PWA deve essere servita da un indirizzo web reale (non funziona aprendo il file da solo sul computer, tranne per una prova rapida). Il modo più semplice e gratuito è **GitHub Pages**:

1. Crea un account gratuito su [github.com](https://github.com) se non ne hai uno.
2. Crea un nuovo repository (ad esempio `soft-plan`), pubblico.
3. Carica tutti i file di questa cartella (mantenendo la struttura, incluso `icons/`) usando "Add file" → "Upload files".
4. Vai su Settings → Pages, e in "Source" scegli il branch `main` e cartella `/root`. Salva.
5. Dopo qualche minuto, GitHub ti darà un indirizzo tipo `https://tuonome.github.io/soft-plan/`.
6. Apri quell'indirizzo dal telefono o dal computer.

## Installare l'app dopo la pubblicazione

**Su Android (Chrome):** apri il link, poi menu (⋮) → "Installa app" o "Aggiungi a schermata Home".

**Su iPhone (Safari):** apri il link, tocca l'icona di condivisione, poi "Aggiungi a Home".

**Su computer (Chrome/Edge):** apri il link, poi clicca l'icona di installazione nella barra degli indirizzi (in alto a destra).

Una volta installata, Soft Plan si apre come un'app a sé stante, con la sua icona, senza la barra del browser.

## Collegare Google Calendar

Dentro l'app, apri "Connetti / esporta" nella barra laterale e segui le istruzioni per ottenere un Client ID Google gratuito. **Importante:** quando crei le credenziali su Google Cloud, come "Origine JavaScript autorizzata" inserisci l'indirizzo del tuo sito pubblicato (es. `https://tuonome.github.io`), non un indirizzo locale — così la connessione resta stabile nel tempo.

## Nota sui dati

Gli impegni sono salvati sul dispositivo su cui usi l'app (nel browser). Se la installi sia su telefono che su computer, i dati non si sincronizzano automaticamente tra i due — per questo conviene collegare Google Calendar, che allora fa da punto di sincronizzazione comune.
